# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
import socket
#import pandas as pd
#import xml.etree.ElementTree as ET

from rclpy.node import Node

from std_msgs.msg import String
import time
import struct

#tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#server_address = ('172.20.66.58', 1200)
#tcp_socket.bind(server_address)

class MinimalPublisher(Node):

    def __init__(self,INNODE):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(String, 'topic', 10)
        
        


    def externalpublish(self,data):
        msg = String()
        msg.data = 'Hello World: %d' 
        self.publisher_.publish(msg)

    def timer_callback(self):

        
        msg = String()
        msg.data = 'Hello World: %d' % self.i
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)
        self.i += 1
def milis():
    return round(time.time() * 1000)

rclpy.init()
node = rclpy.create_node('simple_node')
minimal_publisher = MinimalPublisher(node)

HOST = '172.20.66.58'
PORT = 5001
tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
orig = (HOST, PORT)
tcp.bind(orig)
tcp.listen(1)
while True:
    print("waiting for connection")
    con, client = tcp.accept()
    print ('Connected by', client)
    totalmsg=""
    startms=0
    endMS=0
    STartread=False
    
    while True:


        msg = con.recv(1024)

        if not msg: 
            minimal_publisher.externalpublish(totalmsg)
            endMS=milis()
            
            print("total message:"+totalmsg)
            print("milis"+str(endMS))
            STartread=False
            totalmsg=""
            break
        else:
            if STartread==False:
                STartread=True
                startms=milis()
                print("milis"+str(startms))    
            totalmsg+="{}".format(msg)
        print (client, msg)
    try:
        senddata=int(endMS-startms)
        print("non "+str(senddata))
        #print("encoded"+str(senddata).encode())
        i=struct.pack('i',senddata)
        tcp.send(i)
    except Exception as inst:
        print(inst)
        print("pipe broke")
    print ('Ending client connection', client)
    con.close()


def main(args=None):
    
    rclpy.init(args=args)
    node = rclpy.create_node('simple_node')

    minimal_publisher = MinimalPublisher(node,tcp_socket)

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    tcp_socket.listen(1)

   
    main()

    
