# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
import socket
#import pandas as pd
#import xml.etree.ElementTree as ET

from rclpy.node import Node

from std_msgs.msg import String
import time
import struct
import pandas as pd
import xml.etree.ElementTree as ET
#tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#server_address = ('172.20.66.58', 1200)
#tcp_socket.bind(server_address)
csv = pd.read_csv("./procssing_times_table.csv", sep=";", index_col=0)
class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(String, 'PLCsource', 10)
        
        


    def externalpublish(self,data):
        msg = String()
        msg.data = 'data: '+ str(data) 
        self.publisher_.publish(msg)

    def timer_callback(self):

        
        msg = String()
        msg.data = 'Hello World: %d' % self.i
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)
        self.i += 1
def milis():
    return round(time.time() * 1000)
# iopret node til publishing
#rclpy.init()
#node = rclpy.create_node('simple_node')
#minimal_publisher = MinimalPublisher(node)
# sætter serveren op
HOST = '172.20.66.58'
PORT = 5001
#tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#orig = (HOST, PORT)
#tcp.bind(orig) # bind til ip'en

#tcp.listen(1) 
while False:
    print("waiting for connection")
    con, client = tcp.accept() # vent indtil nogen forbinder til serveren
    print ('Connected by', client)
    totalmsg=""
    startms=0
    endMS=0
    STartread=False
    
    while True: # modtag hele beskeden 1024 bit ad gangen


        msg = con.recv(1024) # læs data

        if not msg: # når der ikke er mere data så skriv beskeden og send returbesked
            minimal_publisher.externalpublish(totalmsg)
            endMS=milis()
            
            print("total message:"+totalmsg)
            print("milis"+str(endMS))
            STartread=False
            totalmsg=""
            break # bryd ud og gå til retur case
        else: # tilføj nuverende data til den fulde besked
            if STartread==False: # hvis det er første gang vi adder data start timeren
                STartread=True
                startms=milis()
                print("milis"+str(startms))    
            totalmsg+="{}".format(msg)# tilføj data til tidligere læst data
        print (client, msg)# skriv data og hvor den kommer fra
    # prøv at sende data tilbage
    try:
        senddata=int(endMS-startms) # mål forskel mellem start og slut af beskeden
        print("non "+str(senddata))
        #print("encoded"+str(senddata).encode())
        i=struct.pack('I',senddata)
        con.sendall(i) # send en besked retur
        print("sleeping")
        time.sleep(6)
    except Exception as inst: # hvis det slår fejl må vi have problemer med forbindelsen
        print(inst)
        print("pipe broke")
    finally:
        con.close()
    print ('Ending client connection', client)
    #con.close() #luk forbindelsen


	
def main(args=None):
    print(len('<data DataTime="DT#2024-05-14-13:26:59" Station_ID="Station#09" Carrier_ID="15"></data>'))
    rclpy.init(args=args)
    node = rclpy.create_node('simple_node')
    minimal_publisher = MinimalPublisher()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = (HOST, PORT)
    sock.bind(server_address)
    sock.listen(1)
    first=True
    print("starting loop")
    while True:
        connection, client_address = sock.accept()
        print("connection established")
        try:
            while True:
                
                data = connection.recv(1024)
                
                
            
                if not data:
                    break
                print(len('<data DataTime="DT#2024-05-14-13:26:59" Station_ID="Station#09" Carrier_ID="15"></data>'))
                endid=str(data).find("</data>")

                redata=str(data)[:89]
                redata=str(redata).replace("</data>\\","</data>",-1)
                redata=str(redata).replace(r"b'","",-1)
                print(redata)
                root = ET.fromstring(redata)
                e1= root.attrib["Station_ID"]
                e2="Carrier#"+ str(root.attrib["Carrier_ID"])

                processing_time = csv[e1][e2]

                response = processing_time
                
                packed_response = struct.pack('I', response)
                
                minimal_publisher.externalpublish(redata)
                
                connection.sendall(response)
    			
                #print(decoded_xml, 'i sent the processing time', packed_response)
        finally:

            connection.close()

            minimal_publisher.destroy_node()

            rclpy.shutdown()



if __name__ == '__main__':
    main()
    
