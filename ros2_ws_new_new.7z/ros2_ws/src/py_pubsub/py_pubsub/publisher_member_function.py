# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
import socket
#import pandas as pd
#import xml.etree.ElementTree as ET

from rclpy.node import Node

from std_msgs.msg import String
import time
import struct
import pandas as pd
import xml.etree.ElementTree as ET
#tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#server_address = ('172.20.66.58', 1200)
#tcp_socket.bind(server_address)
csv = pd.read_csv("./procssing_times_table.csv", sep=";", index_col=0)
class MinimalPublisher(Node): # ros node in charge of publishing on the PLCsource

    def __init__(self):
        super().__init__('minimal_publisher') # initate the note
        self.publisher_ = self.create_publisher(String, 'PLCsource', 10) # create infrastructure to let the node publish to the PLCsource  
        
        


    def externalpublish(self,data): # allows for code which has a refrence to an instance of this class to publish data on the topic
        msg = String() # create an empty string mesage
        msg.data = 'data: '+ str(data)  # insert the data into the empty message
        self.publisher_.publish(msg) # publish the mesage

    def timer_callback(self): #used to publish a static mesage as a callback to some timer managed elsewhere

        
        msg = String()
        msg.data = 'Hello World: %d' % self.i
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%s"' % msg.data)
        self.i += 1
def milis():
    return round(time.time() * 1000)

# sætter serveren op
HOST = '172.20.66.58'
PORT = 5001
def main(args=None):
    rclpy.init(args=args) #load initiation arguments into the node creator
    node = rclpy.create_node('simple_node') # create a new instance of a node alowing this pice of code to be seen by the ros network
    minimal_publisher = MinimalPublisher() # start a publisheer class to let this node publish to the network
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # create a TCP socket server
    server_address = (HOST, PORT) # create a server adress, and comunication port
    sock.bind(server_address) # bind the socket to the created adress
    sock.listen(1) # start listening for incomming comunication on the server adress
    first=True
    print("starting loop") 
    while True:
        connection, client_address = sock.accept() # waits untill a client starts comunicating, the save the connected client socket and a client adress
        print("connection established")
        try:
            while True:
                # 
                data = connection.recv(1024) # catch the next 1024 bytes sent by the client
                
                
            
                if not data: # if no data was recived break this loop and go back to listening for incomming conections
                    break
                    
                redata=str(data)[:89] # cut of the excess data as we know quite precicely how long the data is, 
                # this is highly dependent on the naming convention used by the PLC
                # as there is a 1 char uncertainty we sometimes have an extra \
                redata=str(redata).replace("</data>\\","</data>",-1) # we remove the extra \
                redata=str(redata).replace(r"b'","",-1) # we remove the b' prescript which indiciates the string is encoded as binary data
                #print(redata)
                root = ET.fromstring(redata) # turn the extracted XML data into a struct
                e1= root.attrib["Station_ID"] # extract the station id atribute
                e2="Carrier#"+ str(root.attrib["Carrier_ID"]) # extract the carrier id atribute

                processing_time = csv[e1][e2] # look up the resulting processing time value

                response = processing_time # ready the value for the return message to the PLC client
                
                packed_response = struct.pack('I', response) # pack the responce as an int using the struct library
                
                minimal_publisher.externalpublish(redata) # publish the extracted data to the ros node
                
                connection.sendall(response) # send the packed processing time to the PLC
    			
                #print(decoded_xml, 'i sent the processing time', packed_response)
        finally: # close all asyncronus processe when the program ends as there are multiple threads runing independently

            connection.close()

            minimal_publisher.destroy_node()

            rclpy.shutdown()



if __name__ == '__main__': # go execute the main function
    main()
    
