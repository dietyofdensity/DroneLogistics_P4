# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from rclpy.node import Node

from std_msgs.msg import String


class MinimalSubscriber(Node): # ros node with a simple subscriber callback

    def __init__(self):
        
        super().__init__('minimal_subscriber') # initiate the node such that it can be seen by the ros network
        
        self.subscription = self.create_subscription(
            String ,
            'PLCsource' ,
            self.listener_callback ,
            10) 
            # start a subscription on the PLCsource topic, and load the "listner_callback" function as callback function, updates on the topic will trigger this callback
        
        
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg): # will be called by the subscriber once the topic updates, which will load a message into the msg parameter

        self.get_logger().info('I heard: "%s"' % msg.data) # write the data to the terminal so it can be viewed by an operator

        with open('somefile.txt', 'a') as the_file: # open the logging text file in append mode, such that the data is added whenever it is written to

            the_file.write( msg.data + '\n' ) # write the data to a file such that it can be observed later



def main(args=None):
    rclpy.init(args=args) # initiate the node on the ros network

    minimal_subscriber = MinimalSubscriber() # start an instacance of the subscriber node

    rclpy.spin(minimal_subscriber) # wait until the minimal subscriber is shut down or updated by a topic callback

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_subscriber.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()
